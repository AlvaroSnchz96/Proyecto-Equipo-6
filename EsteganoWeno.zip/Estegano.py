from PIL import Image
import math  # Utilizado sólo para redondear hacia abajo
import cv2

def menu():
    correcto = False
    num = 0
    while (not correcto):
        try:
            num = int(input())
            correcto = True
        except ValueError:
            print('Error, introduce un número entero')

    return num


def tamañoimagen():
    imagen = Image.open("proyimag1T.png")
    tamaño1 = imagen.size
    anchura1 = tamaño1[0]
    altura1 = tamaño1[1]
    print("Proyimag1T.png tiene", anchura1, "de ancho y ", altura1, "de alto")


def opcion1():

        tamañoimagen()

        caracter_terminacion = [1, 1, 1, 1, 1, 1, 1, 1]


        def obtener_representacion_ascii(caracter):
            return ord(caracter)


        def obtener_representacion_binaria(numero):
            return bin(numero)[2:].zfill(8)


        def cambiar_ultimo_bit(byte, nuevo_bit):
            return byte[:-1] + str(nuevo_bit)


        def binario_a_decimal(binario):
            return int(binario, 2)


        def modificar_color(color_original, bit):
            color_binario = obtener_representacion_binaria(color_original)
            color_modificado = cambiar_ultimo_bit(color_binario, bit)
            return binario_a_decimal(color_modificado)


        def obtener_lista_de_bits(texto):
            lista = []
            for letra in texto:
                representacion_ascii = obtener_representacion_ascii(letra)
                representacion_binaria = obtener_representacion_binaria(representacion_ascii)
                for bit in representacion_binaria:
                    lista.append(bit)
            for bit in caracter_terminacion:
                lista.append(bit)
            return lista



        def ocultar_texto(mensaje, ruta_imagen_original="proyimag1T.png", ruta_imagen_salida="proyimod1T.png"):
            print("Ocultando mensaje...".format(mensaje))
            imagen = Image.open(ruta_imagen_original)
            pixeles = imagen.load()

            tamaño = imagen.size
            anchura = tamaño[0]
            altura = tamaño[1]
            print("Proyimag1T.png tiene", anchura, "de ancho y ", altura, "de alto")
            lista = obtener_lista_de_bits(mensaje)
            contador = 0
            longitud = len(lista)
            for x in range(anchura):
                for y in range(altura):
                    if contador < longitud:
                        pixel = pixeles[x, y]

                        rojo = pixel[0]
                        verde = pixel[1]
                        azul = pixel[2]

                        if contador < longitud:
                            rojo_modificado = modificar_color(rojo, lista[contador])
                            contador += 1
                        else:
                            rojo_modificado = rojo

                        if contador < longitud:
                            verde_modificado = modificar_color(verde, lista[contador])
                            contador += 1
                        else:
                            verde_modificado = verde

                        if contador < longitud:
                            azul_modificado = modificar_color(azul, lista[contador])
                            contador += 1
                        else:
                            azul_modificado = azul

                        pixeles[x, y] = (rojo_modificado, verde_modificado, azul_modificado)
                    else:
                        break
                else:
                    continue
                break

            if contador >= longitud:
                print("Mensaje escrito correctamente")
            else:
                print("Advertencia: no se pudo escribir todo el mensaje, sobraron {} caracteres".format(
                    math.floor((longitud - contador) / 8)))

            imagen.save(ruta_imagen_salida)

            imagen1 = Image.open(ruta_imagen_original)
            imagen2 = Image.open(ruta_imagen_salida)

            if imagen1 != imagen2:
                print("El fichero proyimag1T.png es diferente a proyimod1T.png")

        texto = input("Introduzca el mensaje de texto a ocultar: ")
        ocultar_texto(texto, "proyimag1T.png")


def opcion2():

    caracter_terminacion = "11111111"

    def obtener_lsb(byte):
        return byte[-1]

    def obtener_representacion_binaria(numero):
        return bin(numero)[2:].zfill(8)

    def binario_a_decimal(binario):
        return int(binario, 2)

    def caracter_desde_codigo_ascii(numero):
        return chr(numero)

    def leer(ruta_imagen):
        imagen = Image.open(ruta_imagen)
        pixeles = imagen.load()

        tamaño = imagen.size
        anchura = tamaño[0]
        altura = tamaño[1]

        byte = ""
        mensaje = ""

        #print("Proyimag1T.png tiene", anchura, "de ancho y ", altura, "de alto")
        for x in range(anchura):
            for y in range(altura):
                pixel = pixeles[x, y]

                rojo = pixel[0]
                verde = pixel[1]
                azul = pixel[2]

                byte += obtener_lsb(obtener_representacion_binaria(rojo))
                if len(byte) >= 8:
                    if byte == caracter_terminacion:
                        break
                    mensaje += caracter_desde_codigo_ascii(binario_a_decimal(byte))
                    byte = ""

                byte += obtener_lsb(obtener_representacion_binaria(verde))
                if len(byte) >= 8:
                    if byte == caracter_terminacion:
                        break
                    mensaje += caracter_desde_codigo_ascii(binario_a_decimal(byte))
                    byte = ""

                byte += obtener_lsb(obtener_representacion_binaria(azul))
                if len(byte) >= 8:
                    if byte == caracter_terminacion:
                        break
                    mensaje += caracter_desde_codigo_ascii(binario_a_decimal(byte))
                    byte = ""

            else:
                continue
            break
        return mensaje


    mensaje = leer("proyimod1T.png")
    print("El mensaje oculto es:")
    print(mensaje)

def opcion3():

    imagen = cv2.imread('proyimag1T.png')
    img_gris = cv2.cvtColor(imagen, cv2.COLOR_BGR2GRAY)
    #cv2.imshow("color", imagen)
    cv2.imshow("Gris", img_gris)
    cv2.waitKey(0)

salir = False
opcion = 0

while not salir:
    print('\n                        Aplicación Estegano\n')
    print("1) Insertar mensaje oculto en una imagen")
    print("2) Extraer mensaje oculto de una imagen")
    print("3) Convertir la imagen a escala de grises")
    print("4) Salir")

    print("Opcion: ")

    opcion = menu()

    if opcion == 1:

        opcion1()

    elif opcion == 2:

        opcion2()

    elif opcion == 3:

        opcion3()

    elif opcion == 4:

        salir = True

print("Cerrando programa...")





